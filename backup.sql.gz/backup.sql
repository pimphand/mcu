-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: medical_check_up
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `medical_check_up`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `medical_check_up` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `medical_check_up`;

--
-- Table structure for table `audiometris`
--

DROP TABLE IF EXISTS `audiometris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audiometris` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `audiometri_telinga_kanan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audiometri_telinga_kiri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendengaran_telinga_kanan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendengaran_telinga_kiri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kesimpulan` text COLLATE utf8mb4_unicode_ci,
  `saran` text COLLATE utf8mb4_unicode_ci,
  `selesai` tinyint(1) DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audiometris_created_by_fk` (`created_by`),
  KEY `audiometris_updated_by_fk` (`updated_by`),
  KEY `audiometris_participant_id_fk` (`participant_id`),
  KEY `audiometris_employee_id_fk` (`employee_id`),
  CONSTRAINT `audiometris_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audiometris_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audiometris_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audiometris_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audiometris`
--

LOCK TABLES `audiometris` WRITE;
/*!40000 ALTER TABLE `audiometris` DISABLE KEYS */;
/*!40000 ALTER TABLE `audiometris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_created_by_fk` (`created_by`),
  KEY `clients_updated_by_fk` (`updated_by`),
  CONSTRAINT `clients_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `clients_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'C00001','PT COSMO TECHNOLOGY','COSMO','2026-04-09 09:18:37','2026-04-09 09:18:37',NULL,NULL);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contracts_created_by_fk` (`created_by`),
  KEY `contracts_updated_by_fk` (`updated_by`),
  KEY `contracts_client_id_fk` (`client_id`),
  CONSTRAINT `contracts_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `contracts_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `contracts_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
INSERT INTO `contracts` VALUES (1,'KT00099','2026',1,'2026-04-09 09:19:15','2026-04-09 09:19:15',NULL,NULL);
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_created_by_fk` (`created_by`),
  KEY `departments_updated_by_fk` (`updated_by`),
  KEY `departments_client_id_fk` (`client_id`),
  CONSTRAINT `departments_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `departments_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `departments_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'D-00001','HSE & NUTRITIONS',1,'2026-04-09 10:17:56','2026-04-09 10:17:56',NULL,NULL),(2,'D-00002','KANTIN TKA',1,'2026-04-09 10:17:56','2026-04-09 10:17:56',NULL,NULL),(3,'D-00003','KANTIN TKI',1,'2026-04-09 10:17:57','2026-04-09 10:17:57',NULL,NULL),(4,'D-00004','ENGINEERING',1,'2026-04-09 10:17:59','2026-04-09 10:17:59',NULL,NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `divisis`
--

DROP TABLE IF EXISTS `divisis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `divisis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `divisis_created_by_fk` (`created_by`),
  KEY `divisis_updated_by_fk` (`updated_by`),
  KEY `divisis_client_id_fk` (`client_id`),
  CONSTRAINT `divisis_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `divisis_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `divisis_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `divisis`
--

LOCK TABLES `divisis` WRITE;
/*!40000 ALTER TABLE `divisis` DISABLE KEYS */;
INSERT INTO `divisis` VALUES (1,'DV-00001','HSE & NUTRITIONS',1,'2026-04-09 10:17:56','2026-04-09 10:17:56',NULL,NULL),(2,'DV-00002','KANTIN TKA',1,'2026-04-09 10:17:56','2026-04-09 10:17:56',NULL,NULL),(3,'DV-00003','KANTIN TKI',1,'2026-04-09 10:17:57','2026-04-09 10:17:57',NULL,NULL),(4,'DV-00004','ENGINEERING',1,'2026-04-09 10:17:59','2026-04-09 10:17:59',NULL,NULL);
/*!40000 ALTER TABLE `divisis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ekgs`
--

DROP TABLE IF EXISTS `ekgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ekgs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `takikardi` tinyint(1) DEFAULT NULL,
  `bradikardi` tinyint(1) DEFAULT NULL,
  `aritmia` tinyint(1) DEFAULT NULL,
  `aresst` tinyint(1) DEFAULT NULL,
  `penemuan_lain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keadaan_jantung_normal` tinyint(1) DEFAULT NULL,
  `kesimpulan` text COLLATE utf8mb4_unicode_ci,
  `selesai` tinyint(1) DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ekgs_created_by_fk` (`created_by`),
  KEY `ekgs_updated_by_fk` (`updated_by`),
  KEY `ekgs_participant_id_fk` (`participant_id`),
  KEY `ekgs_employee_id_fk` (`employee_id`),
  CONSTRAINT `ekgs_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ekgs_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ekgs_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ekgs_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ekgs`
--

LOCK TABLES `ekgs` WRITE;
/*!40000 ALTER TABLE `ekgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ekgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kelamin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `tempat_lahir` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `golongan_darah` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rhesus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_karyawan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jabatan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profesi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profesi_detail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warga_negara` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_bank` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nomor_rekening` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ttd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_client_id_fk` (`client_id`),
  KEY `employees_created_by_fk` (`created_by`),
  KEY `employees_updated_by_fk` (`updated_by`),
  CONSTRAINT `employees_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'11111','1111111','dr. Dini Desti Susanti MMRS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ttd/dr_dini.png',NULL,NULL,NULL,NULL,NULL),(2,'11112','1111112','Murni Islamiati, A.Md.A.K',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ttd/dr_murni.png',NULL,NULL,NULL,NULL,NULL),(3,'11113','1111113','dr. Ayu Setyowati S, SP.Rad',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_results`
--

DROP TABLE IF EXISTS `general_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `general_results` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mcu_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_id` bigint unsigned NOT NULL,
  `result` text COLLATE utf8mb4_unicode_ci,
  `mcu_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `general_results_participant_id_foreign` (`participant_id`),
  KEY `general_results_client_id_index` (`client_id`),
  KEY `general_results_name_index` (`name`),
  KEY `general_results_mcu_id_index` (`mcu_id`),
  CONSTRAINT `general_results_participant_id_foreign` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_results`
--

LOCK TABLES `general_results` WRITE;
/*!40000 ALTER TABLE `general_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `general_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratoria`
--

DROP TABLE IF EXISTS `laboratoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `laboratoria` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hemoglobin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hematokrit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lekosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trombosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eritrosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `basofil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eosinofil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batang` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `segmen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `limfosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sgot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sgpt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ureum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creatinin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kesimpulan` text COLLATE utf8mb4_unicode_ci,
  `selesai` tinyint(1) DEFAULT NULL,
  `glukosa_puasa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cholesterol_total` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asam_urat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `glukosa_sewaktu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigliserida` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hdl_cholesterol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ldl_cholestero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reduksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `berat_jenis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ph_reaksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warna` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kekeruhan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urobilinogen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bilirubin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eritrosit_urine` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keton` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `protein` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sedimen_epitel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sedimen_eritrosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sedimen_leukosit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sedimen_bakteri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sedimen_kristal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `form_no` int DEFAULT NULL,
  `hbsag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `laboratoria_created_by_fk` (`created_by`),
  KEY `laboratoria_updated_by_fk` (`updated_by`),
  KEY `laboratoria_participant_id_fk` (`participant_id`),
  KEY `laboratoria_employee_id_fk` (`employee_id`),
  KEY `laboratoria_form_no_index` (`form_no`),
  KEY `laboratoria_hbsag_index` (`hbsag`),
  CONSTRAINT `laboratoria_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `laboratoria_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `laboratoria_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `laboratoria_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratoria`
--

LOCK TABLES `laboratoria` WRITE;
/*!40000 ALTER TABLE `laboratoria` DISABLE KEYS */;
INSERT INTO `laboratoria` VALUES (1,'14.3','45','8770','271000','5.2','0','2','6','60','28','4',NULL,NULL,NULL,NULL,'Reduksi Urin Positif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Positif','1030','7','Kuning','Keruh','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',2,2,'2026-04-14 17:17:23','2026-04-15 06:27:09',NULL,1,NULL,'Negatif',1),(2,'14.9','43','12530','371000','5.5','0','3','5','55','34','3',NULL,NULL,NULL,NULL,'Leukosit diatas nilai normal, protein urine positif 1',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','positif','Negatif','0 - 1','2 - 3','Negatif','Negatif',3,2,'2026-04-14 17:17:23','2026-04-15 06:27:34',NULL,1,NULL,'Negatif',1),(3,'15.6','42','8000','231000','4.5','0','1','6','66','24','3',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',7,2,'2026-04-14 17:17:23','2026-04-22 05:05:46',NULL,1,NULL,'Negatif',1),(4,'14.4','42','6210','349000','5','0','2','6','63','25','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 3','Negatif','Negatif',8,2,'2026-04-14 17:17:24','2026-04-15 06:30:24',NULL,1,NULL,'Negatif',1),(5,'14.4','42','9280','316000','4.6','0','2','6','65','24','3',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',9,2,'2026-04-14 17:17:24','2026-04-15 06:27:53',NULL,1,NULL,'Negatif',1),(6,'14.3','40','11200','286000','5','0','2','6','64','22','6',NULL,NULL,NULL,NULL,'Leukosit diatas nilai normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1025','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',11,2,'2026-04-14 17:17:24','2026-04-15 06:35:27',NULL,1,NULL,'Negatif',1),(7,'13.8','39','7940','449000','4.6','0','2','5','55','34','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','7.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 2','Negatif','Negatif',12,2,'2026-04-14 17:17:24','2026-04-15 06:35:34',NULL,1,NULL,'Negatif',1),(8,'13.3','38','5680','245000','4.5','0','1','4','50','40','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',13,2,'2026-04-14 17:17:24','2026-04-15 06:35:43',NULL,1,NULL,'Negatif',1),(9,'13.7','39','5500','184000','4.9','0','1','6','63','25','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 2','Negatif','Negatif',14,2,'2026-04-14 17:17:24','2026-04-15 06:35:53',NULL,1,NULL,'Negatif',1),(10,'13.3','38','8720','219000','4.7','0','3','5','58','30','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',15,2,'2026-04-14 17:17:24','2026-04-15 06:40:23',NULL,1,NULL,'Negatif',1),(11,'14.9','43','7850','445000','4.6','0','1','6','61','27','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1025','7','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 2','Negatif','Negatif',17,2,'2026-04-14 17:17:24','2026-04-15 06:36:11',NULL,1,NULL,'Negatif',1),(12,'12.9','38','7860','308000','4.4','0','1','4','50','40','5',NULL,NULL,NULL,NULL,'Reduksi Urin Positif',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Positif','1030','5','Kuning','Agak Keruh','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',18,2,'2026-04-14 17:17:24','2026-04-15 06:36:18',NULL,1,NULL,'Negatif',1),(13,'12.8','39','9470','253000','4.5','0','2','6','61','27','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','7.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',19,2,'2026-04-14 17:17:24','2026-04-15 06:36:25',NULL,1,NULL,'Negatif',1),(14,'16','45','7660','240000','5','0','3','6','63','25','3',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',20,2,'2026-04-14 17:17:24','2026-04-15 06:36:37',NULL,1,NULL,'Negatif',1),(15,'12.8','38','6480','238000','4.4','0','2','6','65','24','3',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',21,2,'2026-04-14 17:17:24','2026-04-15 06:36:45',NULL,1,NULL,'Negatif',1),(16,'14.5','43','8890','251000','5.2','0','1','6','69','20','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 3','Negatif','Negatif',22,2,'2026-04-14 17:17:24','2026-04-15 06:36:54',NULL,1,NULL,'Negatif',1),(17,'14.6','42','6980','407000','4.5','0','1','6','63','25','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',31,2,'2026-04-14 17:17:24','2026-04-15 06:38:33',NULL,1,NULL,'Negatif',1),(18,'13.3','40','9180','445000','5','0','1','4','50','40','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1025','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',32,2,'2026-04-14 17:17:24','2026-04-15 06:38:42',NULL,1,NULL,'Negatif',1),(19,'12.2','37','8110','378000','4.7','0','2','6','64','24','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 3','Negatif','Negatif',33,2,'2026-04-14 17:17:24','2026-04-15 06:38:23',NULL,1,NULL,'Negatif',1),(20,'13.5','42','8030','341000','5.2','0','2','5','55','33','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',34,2,'2026-04-14 17:17:24','2026-04-15 06:38:04',NULL,1,NULL,'Negatif',1),(21,'13.7','45','8560','246000','5.3','0','3','5','53','33','6',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',35,2,'2026-04-14 17:17:24','2026-04-15 06:38:13',NULL,1,NULL,'Negatif',1),(22,'8.4','33','5240','398000','4','0','3','5','53','33','6',NULL,NULL,NULL,NULL,'Hemoglobin dibawah nilai normal, Hematokrit dibawah nilai normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 3','Negatif','Negatif',36,2,'2026-04-14 17:17:24','2026-04-15 06:26:25',NULL,1,NULL,'Negatif',1),(23,'15.3','50','9490','319000','5.3','0','2','6','63','25','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',1,2,'2026-04-14 17:17:24','2026-04-15 06:26:55',NULL,1,NULL,'Negatif',1),(24,'16','50','5930','158000','5.5','0','3','6','64','22','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 2','Negatif','Negatif',4,2,'2026-04-14 17:17:24','2026-04-15 06:28:32',NULL,1,NULL,'Negatif',1),(25,'16','50','7540','158000','6','0','2','6','61','27','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','7','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 3','Negatif','Negatif',5,2,'2026-04-14 17:17:24','2026-04-15 06:28:46',NULL,1,NULL,'Negatif',1),(26,'16','47','6100','313000','4.5','0','1','5','50','39','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1010','5.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 2','Negatif','Negatif',6,2,'2026-04-14 17:17:24','2026-04-15 06:30:06',NULL,1,NULL,'Negatif',1),(27,'14.7','44','6040','387000','4.6','0','2','6','64','22','6',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',10,2,'2026-04-14 17:17:24','2026-04-15 06:35:21',NULL,1,NULL,'Negatif',1),(28,'14','40','7510','449000','4.6','0','1','4','55','35','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',16,2,'2026-04-14 17:17:24','2026-04-15 06:36:03',NULL,1,NULL,'Negatif',1),(29,'16.5','50','8560','247000','5.9','0','1','4','50','40','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','1 - 3','Negatif','Negatif',23,2,'2026-04-14 17:17:24','2026-04-15 06:37:02',NULL,1,NULL,'Negatif',1),(30,'14.9','44','12510','306000','5.2','0','3','5','54','32','6',NULL,NULL,NULL,NULL,'Leukosit diatas nilai normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 3','Negatif','Negatif',24,2,'2026-04-14 17:17:24','2026-04-15 06:37:16',NULL,1,NULL,'Negatif',1),(31,'15.3','44','7300','262000','5.3','0','3','5','54','32','6',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1030','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 3','Negatif','Negatif',25,2,'2026-04-14 17:17:24','2026-04-15 06:37:24',NULL,1,NULL,'Negatif',1),(32,'14.5','41','9280','170000','4.6','0','1','4','50','40','5',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6.5','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 2','Negatif','Negatif',26,2,'2026-04-14 17:17:24','2026-04-15 06:37:35',NULL,1,NULL,'Negatif',1),(33,'15.3','44','7600','218000','4.6','0','2','5','58','29','6',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1015','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 3','Negatif','Negatif',27,NULL,'2026-04-14 17:17:24','2026-04-14 17:17:24',NULL,NULL,NULL,'Negatif',1),(34,'14.6','45','9320','317000','5.3','0','2','5','59','28','6',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','2 - 4','Negatif','Negatif',28,2,'2026-04-14 17:17:24','2026-04-15 06:37:44',NULL,1,NULL,'Negatif',1),(35,'17.9','50','6690','383000','5.8','0','1','6','63','26','4',NULL,NULL,NULL,NULL,'Normal',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Negatif','1020','6','Kuning','Jernih','Normal','Negatif','Negatif','Negatif','Negatif','Negatif','0 - 1','0 - 3','Negatif','Negatif',29,2,'2026-04-14 17:17:24','2026-04-15 06:37:53',NULL,1,NULL,'Negatif',1);
/*!40000 ALTER TABLE `laboratoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,NULL,'Home','home','/',1,1,NULL,NULL),(2,NULL,'MCU IN/OUT','log-in','/mcu-in-out',2,1,NULL,NULL),(3,NULL,'MCU','folder-plus','#',3,1,NULL,NULL),(4,NULL,'Laporan','file-text','#',4,1,NULL,NULL),(5,NULL,'Master Data','database','#',5,1,NULL,NULL),(6,NULL,'Administrator','monitor','#',6,1,NULL,NULL),(7,3,'Data Peserta','circle','/participant',7,1,NULL,NULL),(8,3,'Register','circle','/participant-register',8,1,NULL,NULL),(9,3,'Print Hasil MCU','circle','/participant-print-mcu',9,1,NULL,NULL),(10,3,'Print Identitas','circle','/participant-print-identitas',10,1,NULL,NULL),(11,3,'Print Peserta','circle','/participant-print',11,1,NULL,NULL),(12,3,'Kartu Peserta','circle','/participant-kartu',12,1,NULL,NULL),(13,3,'Sticker Peserta','circle','/participant-sticker',13,1,NULL,NULL),(14,3,'Upload Validasi Dokter','circle','/participant-upload-validasi-dokter',14,1,NULL,NULL),(15,3,'Upload Hasil EKG','circle','/participant-upload-ekg',15,1,NULL,NULL),(16,3,'Upload Hasil Audiometri','circle','/participant-upload-audiometri',16,1,NULL,NULL),(17,3,'Upload Hasil Spiro','circle','/participant-upload-spiro',17,1,NULL,NULL),(18,3,'Validasi Dokter','circle','/participant-validasi-dokter',18,1,NULL,NULL),(19,3,'Upload Hasil Laboratorium','circle','/participant-upload-laboratorium',19,1,NULL,NULL),(20,3,'Upload Hasil Radiologi','circle','/participant-upload-radilogi',20,1,NULL,NULL),(21,3,'Upload Hasil Umum','circle','/participant-upload-umum',21,1,NULL,NULL),(22,4,'Rekap Register','circle','/report-recap-register',22,1,NULL,NULL),(23,4,'Data Register','circle','/report-data-register',23,1,NULL,NULL),(24,4,'Progress','circle','/report-progress',24,1,NULL,NULL),(25,4,'Hasil','circle','/report-hasil',25,1,NULL,NULL),(26,4,'Rekap Invoice','circle','/report-recap-invoice',26,1,NULL,NULL),(27,4,'Double Register','circle','/report-double-register',27,1,NULL,NULL),(28,4,'Data Invoice','circle','/report-data-invoice',28,1,NULL,NULL),(29,4,'Data Register Kurang','circle','/report-data-register-kurang',29,1,NULL,NULL),(30,4,'Ibu Hamil','circle','/report-ibu-hamil',30,1,NULL,NULL),(31,4,'Pasien Sprio','circle','/report-pasien-spiro',31,1,NULL,NULL),(32,4,'Pasien Rectal','circle','/report-pasien-rectal',32,1,NULL,NULL),(33,4,'Pasien EKG','circle','/report-pasien-ekg',33,1,NULL,NULL),(34,4,'Pasien Audiometri','circle','/report-pasien-audiometri',34,1,NULL,NULL),(35,4,'Pasien Indikasi Unfit','circle','/report-indikasi-unfit',35,1,NULL,NULL),(36,4,'Pasien Disabilitas','circle','/report-pasien-disabilitas',36,1,NULL,NULL),(37,4,'Tensi > 140','circle','/report-tensi',37,1,NULL,NULL),(38,4,'Grafik','circle','/report-grafik',38,1,NULL,NULL),(39,4,'Statistik','circle','/report-statistik',39,1,NULL,NULL),(40,4,'Cari Hasil','circle','/report-cari-hasil',40,1,NULL,NULL),(41,4,'Hasil per MCU','circle','/report-hasil-per-mcu',41,1,NULL,NULL),(42,5,'Master Department','circle','/department',42,1,NULL,NULL),(43,5,'Master Divisi','circle','/divisi',43,1,NULL,NULL),(44,5,'Master Karyawan','circle','/employee',44,1,NULL,NULL),(45,6,'Role','circle','/role',45,1,NULL,NULL),(46,6,'Client','circle','/client',46,1,NULL,NULL),(47,6,'User','circle','/user',47,1,NULL,NULL);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_12_01_152953_create_roles_table',1),(6,'2023_12_01_153115_add_field_role_to_users',1),(7,'2023_12_01_153939_create_menus_table',1),(8,'2023_12_01_160652_create_permissions_table',1),(9,'2023_12_10_202353_create_clients_table',1),(10,'2023_12_10_203136_create_contracts_table',1),(11,'2023_12_10_203459_create_departments_table',1),(12,'2023_12_10_203948_add_field_client_to_users_table',1),(13,'2023_12_10_203950_create_employees_table',1),(14,'2023_12_10_203952_create_divisis_table',1),(15,'2023_12_10_204308_create_participants_table',1),(16,'2023_12_16_074049_create_tanda_vitals_table',1),(17,'2023_12_16_080708_create_pemeriksaan_fisiks_table',1),(18,'2023_12_16_162604_create_laboratoria_table',1),(19,'2023_12_17_113105_create_radiologis_table',1),(20,'2023_12_17_114610_create_spirometris_table',1),(21,'2023_12_26_193704_create_audiometris_table',1),(22,'2024_01_01_175246_create_rectals_table',1),(23,'2024_01_04_192951_create_ekgs_table',1),(24,'2024_10_06_220128_create_jobs_table',1),(25,'2024_10_08_205051_create_validate_doctors_table',1),(26,'2024_10_09_140742_add_date_to_radiologis',1),(27,'2024_10_10_083307_add_no_form_to_participants',1),(28,'2024_10_15_035949_add_form_to_laboratoria',1),(29,'2024_10_15_093706_add_form_to_laboratoria',1),(30,'2024_10_15_152613_create_general_results_table',1),(31,'2025_10_08_104226_add_kacamata_to_periksaan_fisiks',2),(32,'2025_10_13_153250_add_client_id_to_laboratoria',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participants`
--

DROP TABLE IF EXISTS `participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `packet_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `packet_a` tinyint(1) NOT NULL DEFAULT '0',
  `packet_b` tinyint(1) NOT NULL DEFAULT '0',
  `packet_c` tinyint(1) NOT NULL DEFAULT '0',
  `packet_d` tinyint(1) NOT NULL DEFAULT '0',
  `packet_e` tinyint(1) NOT NULL DEFAULT '0',
  `packet_f` tinyint(1) NOT NULL DEFAULT '0',
  `plan_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_u` tinyint(1) NOT NULL DEFAULT '0',
  `plan_a` tinyint(1) NOT NULL DEFAULT '0',
  `plan_e` tinyint(1) NOT NULL DEFAULT '0',
  `plan_s` tinyint(1) NOT NULL DEFAULT '0',
  `plan_r` tinyint(1) NOT NULL DEFAULT '0',
  `lab_special` tinyint(1) NOT NULL DEFAULT '0',
  `register_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `register_date` timestamp NULL DEFAULT NULL,
  `divisi_id` bigint unsigned DEFAULT NULL,
  `department_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `no_form` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `participants_created_by_fk` (`created_by`),
  KEY `participants_updated_by_fk` (`updated_by`),
  KEY `participants_divisi_id_fk` (`divisi_id`),
  KEY `department_id_fk` (`department_id`),
  KEY `participants_user_id_fk` (`user_id`),
  KEY `participants_client_id_fk` (`client_id`),
  KEY `participants_contract_id_fk` (`contract_id`),
  CONSTRAINT `department_id_fk` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_contract_id_fk` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_divisi_id_fk` FOREIGN KEY (`divisi_id`) REFERENCES `divisis` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `participants_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participants`
--

LOCK TABLES `participants` WRITE;
/*!40000 ALTER TABLE `participants` DISABLE KEYS */;
INSERT INTO `participants` VALUES (1,'MCU00001','800160815004','BAGUS IBRAHIM ADIMAN','LAKI- LAKI','1998-05-25','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'1','2026-04-10 01:43:16',1,1,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',1),(2,'MCU00002','800070501048','NURJANAH','PEREMPUAN','1982-09-03','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'2','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',2),(3,'MCU00003','800070810096','ADE NURHAYATI','PEREMPUAN','1983-11-11','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'3','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',3),(4,'MCU00004','800091019225','I KETUT WITRA','LAKI- LAKI','1972-10-17','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'4','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',4),(5,'MCU00005','800130710002','HAIDIR','LAKI- LAKI','1988-11-22','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'5','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',5),(6,'MCU00006','800220809001','LUKI LUKMANUL HAKIM','LAKI- LAKI','1983-06-20','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'6','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:56','2026-04-09 10:19:19',6),(7,'MCU00007','800250203001','MIMIN MINTARSIH','PEREMPUAN','1988-01-25','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'7','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',7),(8,'MCU00008','800230612003','OOY','PEREMPUAN','1977-05-05','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'8','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',8),(9,'MCU00009','800240811001','YENI SURYANITA HANDAYANI','PEREMPUAN','1993-04-28','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'9','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',9),(10,'MCU00010','800230706001','DEDE SUPRIATNA','LAKI- LAKI','1991-06-17','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'10','2026-04-10 01:43:16',2,2,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',10),(11,'MCU00011','800070618071','NENDEN','PEREMPUAN','1972-12-09','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'11','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',11),(12,'MCU00012','800070618072','HENI','PEREMPUAN','1977-06-03','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'12','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:57','2026-04-09 10:19:20',12),(13,'MCU00013','800080701164','ELIS HAYATI','PEREMPUAN','1972-01-01','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'13','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:58','2026-04-09 10:19:21',13),(14,'MCU00014','800080701165','NENENG KARTINI','PEREMPUAN','1974-12-25','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'14','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:58','2026-04-09 10:19:21',14),(15,'MCU00015','800080701166','ENIH SURYANI','PEREMPUAN','1973-04-03','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'15','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:58','2026-04-09 10:19:21',15),(16,'MCU00016','800080815187','ABDUL ROSID','L','1978-08-17',NULL,NULL,NULL,0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'16','2026-04-10 01:43:16',3,3,NULL,1,1,1,1,'2026-04-09 10:17:58','2026-04-10 04:04:28',16),(17,'MCU00017','800100104234','KOKOM KOMARIAH','PEREMPUAN','1972-06-16','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'17','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:58','2026-04-09 10:19:21',17),(18,'MCU00018','800100616261','NURJANAH','PEREMPUAN','1974-07-08','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'18','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:58','2026-04-09 10:19:21',18),(19,'MCU00019','800260105001','ATIK KARTIKA','PEREMPUAN','1982-01-14','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'19','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:21',19),(20,'MCU00020','800260105002','ANGGITA PURWATI','PEREMPUAN','1993-07-25','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'20','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',20),(21,'MCU00021','800260107004','R. INTAN FARAMITA','PEREMPUAN','1989-01-23','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'21','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',21),(22,'MCU00022','800260107003','ESIH','PEREMPUAN','1993-11-21','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'22','2026-04-10 01:43:16',3,3,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',22),(23,'MCU00023','800070507053','YUDI PRIYANTO','LAKI- LAKI','1977-04-03','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'23','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',23),(24,'MCU00024','800250103002','SAPTONO','LAKI- LAKI','1969-11-21','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'24','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',24),(25,'MCU00025','800121001001','DEDE RAHMAT ARIES','LAKI- LAKI','1992-08-01','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'25','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',25),(26,'MCU00026','800170301001','DEDI RUSWANDI','LAKI- LAKI','1982-04-12','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'26','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:17:59','2026-04-09 10:19:22',26),(27,'MCU00027','800231009001','MUDIANA','LAKI- LAKI','1992-02-01','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'27','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:18:00','2026-04-09 10:19:23',27),(28,'MCU00028','800240108001','RIHAN RINALDI','LAKI- LAKI','2005-02-01','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'28','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:18:00','2026-04-09 10:19:23',28),(29,'MCU00029','800250710001','RAEHAN PADUROHMAN','LAKI- LAKI','2007-07-08','','','',0,0,0,0,0,0,'U + R',1,0,0,0,1,0,'29','2026-04-10 01:43:16',4,4,NULL,1,1,1,NULL,'2026-04-09 10:18:00','2026-04-09 10:19:23',29),(31,'MCU00030','320230430381005','SITI HAMIDAH','P','1981-03-30',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_031','2026-04-10 01:43:16',3,3,4,1,1,1,NULL,'2026-04-10 01:13:48','2026-04-10 01:43:16',31),(32,'MCU00031','3202116001050003','MARSYA INTAN NURAENI','P','2005-01-20',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_030','2026-04-10 01:43:16',3,3,5,1,1,1,NULL,'2026-04-10 01:18:50','2026-04-10 01:43:03',30),(33,'MCU00032','3202116712860003','NENENG JULIANTI','P','1986-12-27',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_032','2026-04-10 01:43:16',3,3,6,1,1,1,NULL,'2026-04-10 01:47:29','2026-04-10 01:47:33',32),(34,'MCU00033','3202325608980004','KEUKEU FAMESA','P','1998-08-16',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_034','2026-04-10 01:43:16',3,3,7,1,1,1,NULL,'2026-04-10 01:49:49','2026-04-10 01:49:49',34),(35,'MCU00034','320212700998003','RENI SEPTIANI','P','1998-09-30',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_033','2026-04-10 01:43:16',3,3,8,1,1,1,NULL,'2026-04-10 01:56:48','2026-04-10 02:52:45',33),(36,'MCU00035','3202116507900002','HELMI HERLINA','P','1990-07-25',NULL,'Calon Karyawan','U + R',0,0,0,0,0,0,NULL,1,0,0,0,1,0,'R_100426_035','2026-04-10 07:05:46',3,3,9,1,1,1,NULL,'2026-04-10 07:05:41','2026-04-10 07:05:46',NULL);
/*!40000 ALTER TABLE `participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pemeriksaan_fisiks`
--

DROP TABLE IF EXISTS `pemeriksaan_fisiks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pemeriksaan_fisiks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keadaan_umum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala` tinyint(1) DEFAULT NULL,
  `kepala_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mata` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telinga` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kelainan_telinga` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pupil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buta_warna` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gigi` text COLLATE utf8mb4_unicode_ci,
  `kode_gigi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bibir` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lidah` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenggorokan` tinyint(1) DEFAULT NULL,
  `tenggorokan_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faring` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leher_kgb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leher_jvp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jantung_inspeksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jantung_auskultasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jantung_palpasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jantung_perkusi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_inspeksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_auskultasi_vasikuler` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_auskultasi_ronkhi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_auskultasi_wheezing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_palpasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paru_perkusi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abdomen_inspeksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abdomen_auskultasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abdomen_palpasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abdomen_perkusi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reflex_fisiologis_atas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reflex_fisiologis_bawah` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reflex_phatologis_atas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reflex_phatologis_bawah` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ekg_tidak_diperiksa` tinyint(1) DEFAULT NULL,
  `ekg_bdn` tinyint(1) DEFAULT NULL,
  `ekg_text` text COLLATE utf8mb4_unicode_ci,
  `neurologis_tidak_diperiksa` tinyint(1) DEFAULT NULL,
  `neurologis_bdn` tinyint(1) DEFAULT NULL,
  `neurologis_text` text COLLATE utf8mb4_unicode_ci,
  `fisik_diperiksa` tinyint(1) DEFAULT NULL,
  `selesai` tinyint(1) DEFAULT NULL,
  `visus_diperiksa` tinyint(1) DEFAULT NULL,
  `selesai_visus` tinyint(1) DEFAULT NULL,
  `lab_diperiksa` tinyint(1) DEFAULT NULL,
  `radiologi_diperiksa` tinyint(1) DEFAULT NULL,
  `audiometri_diperiksa` tinyint(1) DEFAULT NULL,
  `ekg_diperiksa` tinyint(1) DEFAULT NULL,
  `spiro_diperiksa` tinyint(1) DEFAULT NULL,
  `rectal_diperiksa` tinyint(1) DEFAULT NULL,
  `kesimpulan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saran` text COLLATE utf8mb4_unicode_ci,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `berkacamata` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pemeriksaan_fisiks_created_by_fk` (`created_by`),
  KEY `pemeriksaan_fisiks_updated_by_fk` (`updated_by`),
  KEY `pemeriksaan_fisiks_participant_id_fk` (`participant_id`),
  KEY `pemeriksaan_fisiks_employee_id_fk` (`employee_id`),
  CONSTRAINT `pemeriksaan_fisiks_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pemeriksaan_fisiks_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pemeriksaan_fisiks_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pemeriksaan_fisiks_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pemeriksaan_fisiks`
--

LOCK TABLES `pemeriksaan_fisiks` WRITE;
/*!40000 ALTER TABLE `pemeriksaan_fisiks` DISABLE KEYS */;
INSERT INTO `pemeriksaan_fisiks` VALUES (1,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/21','NORMAL','DBN+Gigi No: 4 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KANAN ATAS=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies','Ipsum sed ducimus e+KAB4:Karies+KAA3:Karies+KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',4,1,'2026-04-10 02:57:03','2026-04-15 08:25:08',NULL,1,0),(2,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/30','NORMAL','Gigi No: 4 Posisi: KIRI ATAS=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies','KIA4:Karies+KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',3,1,'2026-04-10 03:12:46','2026-04-17 09:27:15',NULL,1,0),(3,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 4 Posisi: KIRI BAWAH=Karies','KIB4:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',21,1,'2026-04-10 03:16:55','2026-04-10 03:16:55',NULL,1,0),(4,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies','KAB3:Karies+KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',10,1,'2026-04-10 03:24:07','2026-04-10 03:24:07',NULL,1,0),(5,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/15 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KANAN ATAS=Karies','KAA3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',33,1,'2026-04-10 03:43:32','2026-04-10 03:43:32',NULL,1,0),(6,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies','KAB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',5,1,'2026-04-10 03:45:52','2026-04-10 03:45:52',NULL,1,0),(7,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 4 Posisi: KIRI BAWAH=Karies','KIB4:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',26,1,'2026-04-10 03:47:48','2026-04-10 03:47:48',NULL,1,0),(8,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( + / + )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',29,1,'2026-04-10 03:52:05','2026-04-10 03:52:05',NULL,1,0),(9,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/7,5','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',1,1,'2026-04-11 06:18:38','2026-04-11 06:18:38',NULL,1,0),(10,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/9 , Mata Kiri 6/12','NORMAL','Gigi No: 4 Posisi: KANAN BAWAH=Tanggal+Gigi No: 2 Posisi: KANAN BAWAH=Tanggal','KAB4:Tanggal+KAB2:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',2,1,'2026-04-11 06:20:38','2026-04-17 09:26:57',NULL,1,0),(11,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN+Gigi No: 4 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies','KAB4:Karies+KAB3:Karies+KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'UNFIT','Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',6,1,'2026-04-11 06:22:30','2026-04-17 09:27:31',NULL,1,0),(12,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/30','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Tanggal+Gigi No: 3 Posisi: KIRI BAWAH=Tanggal','KAB3:Tanggal+KIB3:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',7,1,'2026-04-11 06:24:20','2026-04-17 09:27:52',NULL,1,0),(13,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 4 Posisi: KANAN ATAS=Karies+Gigi No: 4 Posisi: KIRI BAWAH=Karies+Gigi No: 3 Posisi: KIRI ATAS=Karies','KAB3:Karies+KAA4:Karies+KIB4:Karies+KIA3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',8,1,'2026-04-11 06:25:27','2026-04-11 06:25:27',NULL,1,0),(14,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Tanggal','KAB3:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',9,1,'2026-04-11 06:26:29','2026-04-11 06:26:29',NULL,1,0),(15,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/12 , Mata Kiri 6/9','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Tanggal','KAB3:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',11,1,'2026-04-11 06:28:26','2026-04-17 09:28:09',NULL,1,0),(16,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',12,1,'2026-04-11 06:34:09','2026-04-11 06:34:09',NULL,1,0),(17,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/7,5','NORMAL','Gigi No: 4 Posisi: KANAN BAWAH=Karies+Gigi No: 4 Posisi: KANAN ATAS=Karies','KAB4:Karies+KAA4:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',13,1,'2026-04-11 06:35:50','2026-04-17 09:28:22',NULL,1,0),(18,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/7,5','NORMAL','Gigi No: 4 Posisi: KANAN ATAS=Karies+Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies+Gigi No: 3 Posisi: KIRI ATAS=Karies','KAA4:Karies+KAB3:Karies+KIB3:Karies+KIA3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',14,1,'2026-04-11 06:44:37','2026-04-17 09:28:36',NULL,1,0),(19,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/9 , Mata Kiri 6/9','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',15,1,'2026-04-11 06:48:59','2026-04-11 06:48:59',NULL,1,0),(20,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Tanggal','KAB3:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',17,1,'2026-04-11 06:50:30','2026-04-17 09:28:52',NULL,1,0),(21,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KIRI ATAS=Karies+Gigi No: 4 Posisi: KIRI BAWAH=Karies+Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 4 Posisi: KANAN ATAS=Karies','KIA3:Karies+KIB4:Karies+KAB3:Karies+KAA4:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',16,1,'2026-04-11 06:53:17','2026-04-11 06:53:17',NULL,1,0),(22,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/21 , Mata Kiri 6/21','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Tanggal+Gigi No: 2 Posisi: KANAN BAWAH=Tanggal+Gigi No: 2 Posisi: KIRI BAWAH=Tanggal+Gigi No: 3 Posisi: KIRI BAWAH=Tanggal','KAB3:Tanggal+KAB2:Tanggal+KIB2:Tanggal+KIB3:Tanggal','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',18,1,'2026-04-11 06:57:17','2026-04-17 09:29:08',NULL,1,0),(23,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/7,5','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',19,1,'2026-04-11 06:58:41','2026-04-11 06:58:41',NULL,1,0),(24,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies','KAB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',20,1,'2026-04-11 06:59:45','2026-04-11 06:59:45',NULL,1,0),(25,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/30 , Mata Kiri 6/60','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',22,1,'2026-04-11 07:05:35','2026-04-11 07:05:35',NULL,1,1),(26,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KANAN ATAS=Karies+Gigi No: 3 Posisi: KIRI ATAS=Karies','KAA3:Karies+KIA3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',23,1,'2026-04-11 07:17:14','2026-04-11 07:17:14',NULL,1,0),(27,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies+Gigi No: 3 Posisi: KIRI BAWAH=Karies','KAB3:Karies+KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',24,1,'2026-04-11 07:18:51','2026-04-17 09:29:33',NULL,1,0),(28,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 4 Posisi: KIRI ATAS=Karies','KIA4:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',25,1,'2026-04-11 07:27:59','2026-04-11 07:27:59',NULL,1,0),(29,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',27,1,'2026-04-11 07:29:10','2026-04-11 07:29:10',NULL,1,0),(30,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies','KAB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',28,1,'2026-04-11 07:40:51','2026-04-11 07:40:51',NULL,1,0),(31,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KIRI BAWAH=Karies','KIB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',31,1,'2026-04-11 07:42:51','2026-04-17 09:29:53',NULL,1,0),(32,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/7,5 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KANAN BAWAH=Karies','KAB3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',32,1,'2026-04-11 07:44:15','2026-04-11 07:44:15',NULL,1,0),(33,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',35,1,'2026-04-11 07:45:50','2026-04-11 07:45:50',NULL,1,0),(34,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/7,5','NORMAL','Gigi No: 3 Posisi: KIRI ATAS=Karies','KIA3:Karies','Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT','- Olahraga teratur\r\n- Jaga pola makan dan olahraga',34,1,'2026-04-11 07:47:12','2026-04-11 07:47:12',NULL,1,0),(35,'Compost Mentis',1,'Normochepal','Polip ( - / - )','CA( - / - ) SI( - / - )','Serumen ( - / - )','NORMAL','ISOKOR','Mata Kanan 6/6 , Mata Kiri 6/6','NORMAL','DBN',NULL,'Sianosis ( - )','Tyfoid tang ( - )',1,'TAK','TIDAK HIPEREMIS','PEMBESARAN -','MENINGKAT -','IC Tidak Terlihat ( - )','BJ I + BJ II NORMAL','IC TERABA','DALL','Pergerakan Dada Simetris','+ / +','- / -','- / -','Revitasi ( - )','SONOR','SUPEL','BISING USUS NORMAL','Nyeri Tekan Epigastrium ( - )','TIMPANI','+ / +','+ / +','- / -','- / -',0,1,'DBN',0,1,'DBN',1,1,1,1,1,1,0,0,0,0,'FIT WITH RESTRICTION','- Olahraga teratur\r\n- Jaga pola makan\r\n- Konsultasi ke dokter/faskes untuk pemeriksaan lebih lanjut',36,1,'2026-04-11 07:48:06','2026-04-17 09:30:09',NULL,1,0);
/*!40000 ALTER TABLE `pemeriksaan_fisiks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `menu_id` bigint unsigned NOT NULL,
  `is_view` tinyint(1) NOT NULL DEFAULT '0',
  `is_add` tinyint(1) NOT NULL DEFAULT '0',
  `is_edit` tinyint(1) NOT NULL DEFAULT '0',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_permissions_role_id_fk` (`role_id`),
  KEY `role_permissions_menu_id_fk` (`menu_id`),
  CONSTRAINT `role_permissions_menu_id_fk` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`),
  CONSTRAINT `role_permissions_role_id_fk` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,1,1,1,1,1,1,NULL,NULL),(2,1,3,1,1,1,1,NULL,NULL),(3,1,4,1,1,1,1,NULL,NULL),(4,1,6,1,1,1,1,NULL,NULL),(5,1,7,1,1,1,1,NULL,NULL),(6,1,8,1,1,1,1,NULL,NULL),(7,1,9,1,1,1,1,NULL,NULL),(8,1,10,1,1,1,1,NULL,NULL),(9,1,11,1,1,1,1,NULL,NULL),(10,1,12,1,1,1,1,NULL,NULL),(11,1,13,1,1,1,1,NULL,NULL),(12,1,14,1,1,1,1,NULL,NULL),(13,1,15,1,1,1,1,NULL,NULL),(14,1,16,1,1,1,1,NULL,NULL),(15,1,17,1,1,1,1,NULL,NULL),(16,1,18,1,1,1,1,NULL,NULL),(17,1,19,1,1,1,1,NULL,NULL),(18,1,20,1,1,1,1,NULL,NULL),(19,1,21,1,1,1,1,NULL,NULL),(20,1,22,1,1,1,1,NULL,NULL),(21,1,23,1,1,1,1,NULL,NULL),(22,1,24,1,1,1,1,NULL,NULL),(23,1,25,1,1,1,1,NULL,NULL),(24,1,26,1,1,1,1,NULL,NULL),(25,1,27,1,1,1,1,NULL,NULL),(26,1,28,1,1,1,1,NULL,NULL),(27,1,29,1,1,1,1,NULL,NULL),(28,1,30,1,1,1,1,NULL,NULL),(29,1,31,1,1,1,1,NULL,NULL),(30,1,32,1,1,1,1,NULL,NULL),(31,1,33,1,1,1,1,NULL,NULL),(32,1,34,1,1,1,1,NULL,NULL),(33,1,35,1,1,1,1,NULL,NULL),(34,1,36,1,1,1,1,NULL,NULL),(35,1,37,1,1,1,1,NULL,NULL),(36,1,38,1,1,1,1,NULL,NULL),(37,1,39,1,1,1,1,NULL,NULL),(38,1,40,1,1,1,1,NULL,NULL),(39,1,41,1,1,1,1,NULL,NULL),(40,1,45,1,1,1,1,NULL,NULL),(41,1,46,1,1,1,1,NULL,NULL),(42,1,47,1,1,1,1,NULL,NULL),(43,2,1,1,1,1,1,NULL,NULL),(44,2,2,1,1,1,1,NULL,NULL),(45,2,3,1,1,1,1,NULL,NULL),(46,2,4,1,1,1,1,NULL,NULL),(47,2,5,1,1,1,1,NULL,NULL),(48,2,6,1,1,1,1,NULL,NULL),(49,2,7,1,1,1,1,NULL,NULL),(50,2,8,1,1,1,1,NULL,NULL),(51,2,9,1,1,1,1,NULL,NULL),(52,2,10,1,1,1,1,NULL,NULL),(53,2,11,1,1,1,1,NULL,NULL),(54,2,12,1,1,1,1,NULL,NULL),(55,2,13,1,1,1,1,NULL,NULL),(56,2,14,1,1,1,1,NULL,NULL),(57,2,15,1,1,1,1,NULL,NULL),(58,2,16,1,1,1,1,NULL,NULL),(59,2,17,1,1,1,1,NULL,NULL),(60,2,18,1,1,1,1,NULL,NULL),(61,2,19,1,1,1,1,NULL,NULL),(62,2,20,1,1,1,1,NULL,NULL),(63,2,21,1,1,1,1,NULL,NULL),(64,2,22,1,1,1,1,NULL,NULL),(65,2,23,1,1,1,1,NULL,NULL),(66,2,24,1,1,1,1,NULL,NULL),(67,2,25,1,1,1,1,NULL,NULL),(68,2,26,1,1,1,1,NULL,NULL),(69,2,27,1,1,1,1,NULL,NULL),(70,2,28,1,1,1,1,NULL,NULL),(71,2,29,1,1,1,1,NULL,NULL),(72,2,30,1,1,1,1,NULL,NULL),(73,2,31,1,1,1,1,NULL,NULL),(74,2,32,1,1,1,1,NULL,NULL),(75,2,33,1,1,1,1,NULL,NULL),(76,2,34,1,1,1,1,NULL,NULL),(77,2,35,1,1,1,1,NULL,NULL),(78,2,36,1,1,1,1,NULL,NULL),(79,2,37,1,1,1,1,NULL,NULL),(80,2,38,1,1,1,1,NULL,NULL),(81,2,39,1,1,1,1,NULL,NULL),(82,2,40,1,1,1,1,NULL,NULL),(83,2,41,1,1,1,1,NULL,NULL),(84,2,42,1,1,1,1,NULL,NULL),(85,2,43,1,1,1,1,NULL,NULL),(86,2,44,1,1,1,1,NULL,NULL),(87,2,47,1,1,1,1,NULL,NULL),(88,3,1,1,1,1,1,NULL,NULL),(89,3,3,1,1,1,1,NULL,NULL),(90,3,4,1,1,1,1,NULL,NULL),(91,3,7,1,1,1,1,NULL,NULL),(92,3,8,1,1,1,1,NULL,NULL),(93,3,9,1,1,1,1,NULL,NULL),(94,3,10,1,1,1,1,NULL,NULL),(95,3,11,1,1,1,1,NULL,NULL),(96,3,12,1,1,1,1,NULL,NULL),(97,3,13,1,1,1,1,NULL,NULL),(98,3,14,1,1,1,1,NULL,NULL),(99,3,15,1,1,1,1,NULL,NULL),(100,3,16,1,1,1,1,NULL,NULL),(101,3,17,1,1,1,1,NULL,NULL),(102,3,18,1,1,1,1,NULL,NULL),(103,3,19,1,1,1,1,NULL,NULL),(104,3,20,1,1,1,1,NULL,NULL),(105,3,21,1,1,1,1,NULL,NULL),(106,3,22,1,1,1,1,NULL,NULL),(107,3,23,1,1,1,1,NULL,NULL),(108,3,24,1,1,1,1,NULL,NULL),(109,3,25,1,1,1,1,NULL,NULL),(110,3,26,1,1,1,1,NULL,NULL),(111,3,27,1,1,1,1,NULL,NULL),(112,3,28,1,1,1,1,NULL,NULL),(113,3,29,1,1,1,1,NULL,NULL),(114,3,30,1,1,1,1,NULL,NULL),(115,3,31,1,1,1,1,NULL,NULL),(116,3,32,1,1,1,1,NULL,NULL),(117,3,33,1,1,1,1,NULL,NULL),(118,3,34,1,1,1,1,NULL,NULL),(119,3,35,1,1,1,1,NULL,NULL),(120,3,36,1,1,1,1,NULL,NULL),(121,3,37,1,1,1,1,NULL,NULL),(122,3,38,1,1,1,1,NULL,NULL),(123,3,39,1,1,1,1,NULL,NULL),(124,3,40,1,1,1,1,NULL,NULL),(125,3,41,1,1,1,1,NULL,NULL),(126,1,42,1,1,1,1,'2026-04-09 10:53:38','2026-04-09 10:53:52'),(127,1,43,1,1,1,1,'2026-04-09 10:53:53','2026-04-09 10:53:56'),(128,1,44,1,1,1,1,'2026-04-09 10:53:58','2026-04-09 10:54:01');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radiologis`
--

DROP TABLE IF EXISTS `radiologis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `radiologis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cor` text COLLATE utf8mb4_unicode_ci,
  `diafragma_sinus` text COLLATE utf8mb4_unicode_ci,
  `pulmo` text COLLATE utf8mb4_unicode_ci,
  `kesan` text COLLATE utf8mb4_unicode_ci,
  `selesai` tinyint(1) DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `date_mcu` date DEFAULT NULL,
  `diperiksa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `radiologis_created_by_fk` (`created_by`),
  KEY `radiologis_updated_by_fk` (`updated_by`),
  KEY `radiologis_participant_id_fk` (`participant_id`),
  KEY `radiologis_employee_id_fk` (`employee_id`),
  CONSTRAINT `radiologis_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `radiologis_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `radiologis_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `radiologis_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radiologis`
--

LOCK TABLES `radiologis` WRITE;
/*!40000 ALTER TABLE `radiologis` DISABLE KEYS */;
INSERT INTO `radiologis` VALUES (1,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,36,3,'2026-04-15 07:43:43','2026-04-15 07:46:24',NULL,1,NULL,NULL),(2,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,1,3,'2026-04-15 07:45:48','2026-04-15 07:46:31',NULL,1,NULL,NULL),(3,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,2,3,'2026-04-15 07:47:04','2026-04-15 07:47:04',NULL,1,NULL,NULL),(4,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,3,3,'2026-04-15 07:47:37','2026-04-15 07:47:37',NULL,1,NULL,NULL),(5,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,5,3,'2026-04-15 07:49:16','2026-04-15 07:49:16',NULL,1,NULL,NULL),(6,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,4,3,'2026-04-15 07:49:55','2026-04-15 07:49:55',NULL,1,NULL,NULL),(7,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,7,3,'2026-04-15 07:51:59','2026-04-15 07:51:59',NULL,1,NULL,NULL),(8,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,8,3,'2026-04-15 07:52:38','2026-04-15 07:52:38',NULL,1,NULL,NULL),(9,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,9,3,'2026-04-15 07:54:10','2026-04-15 07:54:14',NULL,1,NULL,NULL),(10,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,10,3,'2026-04-15 07:56:45','2026-04-15 07:56:45',NULL,1,NULL,NULL),(11,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,11,3,'2026-04-15 07:57:17','2026-04-15 07:57:17',NULL,1,NULL,NULL),(12,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,12,3,'2026-04-15 07:57:50','2026-04-15 07:57:50',NULL,1,NULL,NULL),(13,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,13,3,'2026-04-15 07:58:20','2026-04-15 07:58:20',NULL,1,NULL,NULL),(14,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,14,3,'2026-04-15 07:58:45','2026-04-15 07:58:45',NULL,1,NULL,NULL),(15,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,15,3,'2026-04-15 08:00:05','2026-04-15 08:00:05',NULL,1,NULL,NULL),(16,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,16,3,'2026-04-15 08:00:35','2026-04-15 08:00:35',NULL,1,NULL,NULL),(17,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,17,3,'2026-04-15 08:01:40','2026-04-15 08:01:40',NULL,1,NULL,NULL),(18,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,18,3,'2026-04-15 08:02:05','2026-04-15 08:02:05',NULL,1,NULL,NULL),(19,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,19,3,'2026-04-15 08:02:30','2026-04-15 08:02:30',NULL,1,NULL,NULL),(20,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,20,3,'2026-04-15 08:03:09','2026-04-15 08:03:09',NULL,1,NULL,NULL),(21,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,21,3,'2026-04-15 08:03:30','2026-04-15 08:03:30',NULL,1,NULL,NULL),(22,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,22,3,'2026-04-15 08:03:52','2026-04-15 08:03:52',NULL,1,NULL,NULL),(23,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,23,3,'2026-04-15 08:04:18','2026-04-15 08:04:18',NULL,1,NULL,NULL),(24,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,24,3,'2026-04-15 08:05:02','2026-04-15 08:05:02',NULL,1,NULL,NULL),(25,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,25,3,'2026-04-15 08:05:26','2026-04-15 08:05:26',NULL,1,NULL,NULL),(26,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,26,3,'2026-04-15 08:05:57','2026-04-15 08:05:57',NULL,1,NULL,NULL),(27,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,27,3,'2026-04-15 08:06:41','2026-04-15 08:06:41',NULL,1,NULL,NULL),(28,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,28,3,'2026-04-15 08:07:01','2026-04-15 08:07:01',NULL,1,NULL,NULL),(29,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,29,3,'2026-04-15 08:08:27','2026-04-15 08:08:27',NULL,1,NULL,NULL),(30,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,32,3,'2026-04-15 08:10:29','2026-04-15 08:17:13',NULL,1,NULL,NULL),(31,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,31,3,'2026-04-15 08:10:50','2026-04-15 08:10:54',NULL,1,NULL,NULL),(32,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,33,3,'2026-04-15 08:11:29','2026-04-15 08:11:29',NULL,1,NULL,NULL),(33,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,34,3,'2026-04-15 08:17:44','2026-04-15 08:17:44',NULL,1,NULL,NULL),(34,'CTR < 50%. Bentuk dan letak normal.','Kedua hilus tak membesar, Diafragma baik, Sinus kostofrenikus kanan-kiri lancip, Tulang-tulang intak, Soft tissue baik.','Corakan bronchovasculer normal. Tak tampak infiltrat pada kedua paru. Kedua apeks tenang.','- Cor tak membesar.\r\n- Pulmo tak tampak kelainan.',1,35,3,'2026-04-15 08:18:09','2026-04-15 08:18:09',NULL,1,NULL,NULL),(35,'CTR < 50 %. Bentuk dan letak normal','- Kedua hilus tampak menebal.\r\n- Diafragma baik\r\n- Sinus kostofrenikus kanan-kiri lancip.\r\n- Tulang-tulang intak.\r\n- Soft tissue baik.','Corakan bronchovasculer meningkat. Tampak infiltrat pada perihilar kanan-kiri dan parakardial kanan-kiri.','- Cor tak membesar.\r\n- Gambaran bronkopneumonia DD/ TB pulmo.',1,6,3,'2026-04-15 08:32:28','2026-04-15 14:28:36',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `radiologis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rectals`
--

DROP TABLE IF EXISTS `rectals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rectals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `salmonella_thypi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shigella_sp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `e_coli_pathogen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kesimpulan` text COLLATE utf8mb4_unicode_ci,
  `selesai` tinyint(1) DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rectals_created_by_fk` (`created_by`),
  KEY `rectals_updated_by_fk` (`updated_by`),
  KEY `rectals_participant_id_fk` (`participant_id`),
  KEY `rectals_employee_id_fk` (`employee_id`),
  CONSTRAINT `rectals_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rectals_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rectals_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rectals_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rectals`
--

LOCK TABLES `rectals` WRITE;
/*!40000 ALTER TABLE `rectals` DISABLE KEYS */;
INSERT INTO `rectals` VALUES (1,'Negatif','Negatif','Negatif','Normal',1,1,2,'2026-04-14 11:51:07','2026-04-14 11:51:07',NULL,1),(2,'Negatif','Negatif','Negatif','Normal',1,2,2,'2026-04-14 11:51:32','2026-04-14 11:51:32',NULL,1),(3,'Negatif','Negatif','Negatif','Normal',1,3,2,'2026-04-14 11:51:50','2026-04-14 11:51:50',NULL,1),(4,'Negatif','Negatif','Negatif','Normal',1,4,2,'2026-04-14 11:52:27','2026-04-14 11:52:27',NULL,1),(5,'Negatif','Negatif','Negatif','Normal',1,5,2,'2026-04-14 11:53:04','2026-04-14 11:53:04',NULL,1),(6,'Negatif','Negatif','Negatif','Normal',1,6,2,'2026-04-14 11:53:22','2026-04-14 11:53:22',NULL,1),(7,'Negatif','Negatif','Negatif','Normal',1,7,2,'2026-04-14 11:54:07','2026-04-14 11:54:07',NULL,1),(8,'Negatif','Negatif','Negatif','Normal',1,8,2,'2026-04-14 11:54:30','2026-04-14 11:54:30',NULL,1),(9,'Negatif','Negatif','Negatif','Normal',1,9,2,'2026-04-14 11:54:50','2026-04-14 11:54:50',NULL,1),(10,'Negatif','Negatif','Negatif','Normal',1,10,2,'2026-04-14 11:55:10','2026-04-14 11:55:10',NULL,1),(11,'Negatif','Negatif','Negatif','Normal',1,11,2,'2026-04-14 11:55:27','2026-04-14 11:55:27',NULL,1),(12,'Negatif','Negatif','Negatif','Normal',1,12,2,'2026-04-14 11:55:46','2026-04-14 11:55:46',NULL,1),(13,'Negatif','Negatif','Negatif','Normal',1,13,2,'2026-04-14 11:56:07','2026-04-14 11:56:07',NULL,1),(14,'Negatif','Negatif','Negatif','Normal',1,14,2,'2026-04-14 11:56:23','2026-04-14 11:56:23',NULL,1),(15,'Negatif','Negatif','Negatif','Normal',1,19,2,'2026-04-14 11:57:23','2026-04-14 11:57:23',NULL,1),(16,'Negatif','Negatif','Negatif','Normal',1,20,2,'2026-04-14 11:57:50','2026-04-14 11:57:50',NULL,1),(17,'Negatif','Negatif','Negatif','Normal',1,21,2,'2026-04-14 11:58:05','2026-04-14 11:58:05',NULL,1),(18,'Negatif','Negatif','Negatif','Normal',1,22,2,'2026-04-14 11:58:21','2026-04-14 11:58:21',NULL,1),(19,'Negatif','Negatif','Negatif','Normal',1,23,2,'2026-04-14 11:58:39','2026-04-14 11:58:39',NULL,1),(20,'Negatif','Negatif','Negatif','Normal',1,24,2,'2026-04-14 11:58:52','2026-04-14 11:58:52',NULL,1),(21,'Negatif','Negatif','Negatif','Normal',1,25,2,'2026-04-14 11:59:09','2026-04-14 11:59:09',NULL,1),(22,'Negatif','Negatif','Negatif','Normal',1,26,2,'2026-04-14 11:59:27','2026-04-14 11:59:27',NULL,1),(23,'Negatif','Negatif','Negatif','Normal',1,27,2,'2026-04-14 11:59:49','2026-04-14 11:59:49',NULL,1),(24,'Negatif','Negatif','Negatif','Normal',1,28,2,'2026-04-14 12:00:13','2026-04-14 12:00:13',NULL,1),(25,'Negatif','Negatif','Negatif','Normal',1,32,2,'2026-04-14 12:01:13','2026-04-14 12:01:13',NULL,1),(26,'Negatif','Negatif','Negatif','Normal',1,31,2,'2026-04-14 12:01:34','2026-04-14 12:01:34',NULL,1),(27,'Negatif','Negatif','Negatif','Normal',1,33,2,'2026-04-14 12:01:56','2026-04-14 12:01:56',NULL,1),(28,'Negatif','Negatif','Negatif','Normal',1,35,2,'2026-04-14 12:02:14','2026-04-14 12:02:14',NULL,1),(29,'Negatif','Negatif','Negatif','Normal',1,34,2,'2026-04-14 12:02:33','2026-04-14 12:02:33',NULL,1),(30,'Negatif','Negatif','Negatif','Normal',1,36,2,'2026-04-14 12:03:15','2026-04-14 12:03:15',NULL,1),(31,'Negatif','Negatif','Negatif','Normal',1,18,2,'2026-04-14 12:04:30','2026-04-14 12:04:30',NULL,1),(32,'Negatif','Negatif','Negatif','Normal',1,16,2,'2026-04-14 12:04:50','2026-04-14 12:04:50',NULL,1),(33,'Negatif','Negatif','Negatif','Normal',1,29,2,'2026-04-14 12:05:09','2026-04-14 12:05:09',NULL,1),(34,'Negatif','Negatif','Negatif','Normal',1,17,2,'2026-04-14 12:06:09','2026-04-14 12:06:09',NULL,1),(35,'Negatif','Negatif','Negatif','Normal',1,15,2,'2026-04-14 12:06:30','2026-04-14 12:06:30',NULL,1);
/*!40000 ALTER TABLE `rectals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `level` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_level_unique` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,1,'Administrator',1,NULL,NULL),(2,2,'Admin Client',1,NULL,NULL),(3,3,'Admin Karyawan',1,NULL,NULL),(4,4,'Peserta',1,NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spirometris`
--

DROP TABLE IF EXISTS `spirometris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spirometris` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `lainnya` tinyint(1) DEFAULT NULL,
  `mixed` tinyint(1) DEFAULT NULL,
  `normal` tinyint(1) DEFAULT NULL,
  `obstructive` tinyint(1) DEFAULT NULL,
  `restrictive` tinyint(1) DEFAULT NULL,
  `hasil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retriksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obstruksif` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selesai` tinyint(1) DEFAULT NULL,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `spirometris_created_by_fk` (`created_by`),
  KEY `spirometris_updated_by_fk` (`updated_by`),
  KEY `spirometris_participant_id_fk` (`participant_id`),
  KEY `spirometris_employee_id_fk` (`employee_id`),
  CONSTRAINT `spirometris_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `spirometris_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `spirometris_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `spirometris_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spirometris`
--

LOCK TABLES `spirometris` WRITE;
/*!40000 ALTER TABLE `spirometris` DISABLE KEYS */;
/*!40000 ALTER TABLE `spirometris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tanda_vitals`
--

DROP TABLE IF EXISTS `tanda_vitals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tanda_vitals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `participant_id` bigint unsigned DEFAULT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `keluhan_utama` tinyint(1) DEFAULT NULL,
  `keluhan_utama_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `riwayat_penyakit_sekarang` tinyint(1) DEFAULT NULL,
  `riwayat_penyakit_sekarang_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `riwayat_penyakit_terdahulu` tinyint(1) DEFAULT NULL,
  `riwayat_penyakit_terdahulu_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alergi` tinyint(1) DEFAULT NULL,
  `alergi_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merokok` tinyint(1) DEFAULT NULL,
  `konsumsi_alkohol` tinyint(1) DEFAULT NULL,
  `riwayat_trauma` tinyint(1) DEFAULT NULL,
  `riwayat_trauma_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tinggi_badan` int DEFAULT NULL,
  `berat_badan` int DEFAULT NULL,
  `imt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imt_nilai` int DEFAULT NULL,
  `tekanan_darah` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frekuensi_nadi` int DEFAULT NULL,
  `frekuensi_nafas` int DEFAULT NULL,
  `suhu` int DEFAULT NULL,
  `ttv_diperiksa` tinyint(1) DEFAULT NULL,
  `ibu_hamil` tinyint(1) DEFAULT NULL,
  `vaksin_hepatitis` tinyint(1) DEFAULT NULL,
  `vaksin_tetanus` tinyint(1) DEFAULT NULL,
  `selesai` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tanda_vitals_created_by_fk` (`created_by`),
  KEY `tanda_vitals_updated_by_fk` (`updated_by`),
  KEY `tanda_vitals_employee_id_fk` (`employee_id`),
  KEY `tanda_vitals_participant_id_fk` (`participant_id`),
  CONSTRAINT `tanda_vitals_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tanda_vitals_employee_id_fk` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tanda_vitals_participant_id_fk` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tanda_vitals_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tanda_vitals`
--

LOCK TABLES `tanda_vitals` WRITE;
/*!40000 ALTER TABLE `tanda_vitals` DISABLE KEYS */;
INSERT INTO `tanda_vitals` VALUES (1,4,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',159,79,'OBESITAS',32,'130/90',80,20,37,1,0,0,0,1,'2026-04-10 03:03:45','2026-04-10 03:03:45',NULL,1),(2,3,1,0,'BATUK, PILEK',0,'HIPERTENSI',0,'HIPERTENSI',1,'TIDAK',0,0,1,'TIDAK',91,150,'OBESITAS',181,'180/100',86,20,37,1,0,0,0,1,'2026-04-10 03:11:48','2026-04-10 03:11:48',NULL,1),(3,21,1,0,'PUSING',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',162,64,'NORMAL',24,'130/90',80,20,37,1,0,0,0,1,'2026-04-10 03:15:17','2026-04-10 03:15:17',NULL,1),(4,10,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',163,72,'GEMUK',27,'130/90',80,20,37,1,0,0,0,1,'2026-04-10 03:23:45','2026-04-10 03:23:45',NULL,1),(5,33,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',147,69,'OBESITAS',32,'120/80',80,20,37,1,0,0,0,1,'2026-04-10 03:42:47','2026-04-10 03:42:47',NULL,1),(6,5,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',171,95,'OBESITAS',32,'110/80',87,20,37,1,0,0,0,1,'2026-04-10 03:45:29','2026-04-10 03:45:29',NULL,1),(7,26,1,1,'TAK',1,'TAK',1,'-',0,'DINGIN',1,0,1,'TIDAK',166,53,'NORMAL',19,'110/70',84,20,38,1,0,0,0,1,'2026-04-10 03:47:23','2026-04-10 03:47:23',NULL,1),(8,29,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',1,0,1,'TIDAK',165,46,'KURUS',17,'120/80',86,20,37,1,0,0,0,1,'2026-04-10 03:49:09','2026-04-10 03:49:09',NULL,1),(9,1,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',55,163,'OBESITAS',539,'90/80',84,20,36,1,0,0,0,1,'2026-04-11 06:18:15','2026-04-11 06:18:15',NULL,1),(10,2,1,1,'TAK',0,'HIPERTENSI',0,'HIPERTENSI',1,'TIDAK',0,0,1,'TIDAK',159,66,'GEMUK',26,'160/100',88,20,37,1,0,0,0,1,'2026-04-11 06:19:56','2026-04-11 06:19:56',NULL,1),(11,6,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',168,85,'OBESITAS',30,'100/80',85,20,37,1,0,0,0,1,'2026-04-11 06:22:07','2026-04-11 06:22:07',NULL,1),(12,7,1,1,'TAK',0,'HIPERTENSI',0,'HIPERTENSI',1,'TIDAK',0,0,1,'TIDAK',145,57,'GEMUK',27,'180/100',87,20,37,1,0,0,0,1,'2026-04-11 06:23:25','2026-04-11 06:23:25',NULL,1),(13,8,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',151,54,'NORMAL',24,'120/80',86,20,36,1,0,0,0,1,'2026-04-11 06:25:00','2026-04-11 06:25:00',NULL,1),(14,9,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',155,54,'NORMAL',22,'110/80',82,20,37,1,0,0,0,1,'2026-04-11 06:26:07','2026-04-11 06:26:07',NULL,1),(15,11,1,0,'SAKIT BADAN',0,'HIPERTENSI, DIABETES',0,'HIPERTENSI, DIABETES',1,'TIDAK',1,0,1,'TIDAK',160,62,'NORMAL',24,'120/80',87,20,37,1,0,0,0,1,'2026-04-11 06:27:55','2026-04-11 06:27:55',NULL,1),(16,12,1,1,'TAK',1,'TAK',0,'VERTIGO',1,'TIDAK',0,0,1,'TIDAK',144,54,'GEMUK',26,'110/80',84,20,37,1,0,0,0,1,'2026-04-11 06:33:45','2026-04-11 06:33:45',NULL,1),(17,13,1,0,'SAKIT GIGI',1,'TAK',0,'HIPERTENSI',1,'TIDAK',0,0,1,'TIDAK',157,77,'OBESITAS',31,'140/90',86,20,37,1,0,0,0,1,'2026-04-11 06:35:05','2026-04-11 06:35:05',NULL,1),(18,14,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',150,54,'NORMAL',24,'150/100',84,20,37,1,0,0,0,1,'2026-04-11 06:42:43','2026-04-11 06:42:43',NULL,1),(19,15,1,1,'TAK',0,'JANTUNG, HIPERTENSI',1,'-',1,'TIDAK',0,0,1,'TIDAK',145,73,'OBESITAS',35,'110/80',85,20,37,1,0,0,0,1,'2026-04-11 06:48:34','2026-04-11 06:48:34',NULL,1),(20,17,1,1,'TAK',0,'HIPETENSI',0,'HIPERTENSI',1,'TIDAK',1,0,1,'TIDAK',148,77,'OBESITAS',35,'150/100',87,20,37,1,0,0,0,1,'2026-04-11 06:50:04','2026-04-11 06:50:04',NULL,1),(21,16,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',1,0,1,'TIDAK',161,64,'NORMAL',25,'120/80',84,20,36,1,0,0,0,1,'2026-04-11 06:52:41','2026-04-11 06:52:41',NULL,1),(22,18,1,1,'TAK',0,'DIABETES',1,'-',1,'TIDAK',0,0,1,'TIDAK',146,63,'OBESITAS',30,'120/80',84,20,37,1,0,0,0,1,'2026-04-11 06:56:21','2026-04-11 06:56:21',NULL,1),(23,19,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',149,67,'OBESITAS',30,'100/80',84,20,37,1,0,0,0,1,'2026-04-11 06:58:14','2026-04-11 06:58:14',NULL,1),(24,20,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',156,48,'NORMAL',20,'100/80',85,20,37,1,0,0,0,1,'2026-04-11 06:59:23','2026-04-11 06:59:23',NULL,1),(25,22,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',151,63,'OBESITAS',28,'100/80',87,20,37,1,0,0,0,1,'2026-04-11 07:05:02','2026-04-11 07:05:02',NULL,1),(26,23,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',163,60,'NORMAL',23,'100/70',80,20,36,1,0,0,0,1,'2026-04-11 07:14:00','2026-04-11 07:14:00',NULL,1),(27,24,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',161,71,'GEMUK',27,'140/90',80,20,37,1,0,0,0,1,'2026-04-11 07:18:14','2026-04-11 07:18:14',NULL,1),(28,25,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',180,85,'GEMUK',26,'120/80',88,20,37,1,0,0,0,1,'2026-04-11 07:27:42','2026-04-11 07:27:42',NULL,1),(29,27,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',1,0,1,'TIDAK',170,58,'NORMAL',20,'110/80',84,20,36,1,0,0,0,1,'2026-04-11 07:28:54','2026-04-11 07:28:54',NULL,1),(30,28,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',1,0,1,'TIDAK',162,49,'NORMAL',19,'120/80',87,20,37,1,0,0,0,1,'2026-04-11 07:40:03','2026-04-11 07:40:03',NULL,1),(31,31,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',50,146,'OBESITAS',584,'150/100',84,20,37,1,0,0,0,1,'2026-04-11 07:42:20','2026-04-11 07:42:20',NULL,1),(32,32,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',157,66,'GEMUK',27,'110/80',85,20,37,1,0,0,0,1,'2026-04-11 07:43:38','2026-04-11 07:43:38',NULL,1),(33,35,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',156,72,'OBESITAS',30,'120/80',80,20,37,1,0,0,0,1,'2026-04-11 07:44:57','2026-04-11 07:45:32',NULL,1),(34,34,1,1,'TAK',1,'TAK',1,'-',0,'CUACA DINGIN',0,0,1,'TIDAK',156,74,'OBESITAS',30,'90/80',80,20,37,1,0,0,0,1,'2026-04-11 07:46:45','2026-04-11 07:46:45',NULL,1),(35,36,1,1,'TAK',1,'TAK',1,'-',1,'TIDAK',0,0,1,'TIDAK',157,51,'NORMAL',21,'100/80',85,20,37,1,0,0,0,1,'2026-04-11 07:47:53','2026-04-11 07:47:53',NULL,1);
/*!40000 ALTER TABLE `tanda_vitals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `role_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_role_id_fk` (`role_id`),
  KEY `users_client_id_fk` (`client_id`),
  CONSTRAINT `users_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_role_id_fk` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin','admin','admin@admin.com',NULL,NULL,'$2y$12$kQw9dOKxWhr5KJ/94Wch8uEn8yo4LdQ.KFN.6b1d4HIdU8yyaAD1O',1,NULL,NULL,NULL,NULL,1,NULL),(2,'COSMO_KANTIN','C00001',NULL,NULL,NULL,'$2y$12$OC7IK1u.pSuaIfhCE0gcWuxqleMT4gQeUCS3TBkCSAqe7LYMqCThm',0,NULL,'2026-04-09 09:18:38','2026-04-09 09:18:38',NULL,2,1),(3,'nusa','MCU00030_30',NULL,NULL,NULL,'$2y$12$awFVMZHOBu2Islade4zEwe6j0YNFLJQ4cxDJfbXhbDLaNVbnTkOs.',1,NULL,'2026-04-09 11:03:00','2026-04-09 11:03:00',NULL,4,1),(4,'SITI HAMIDAH','MCU00030_31',NULL,NULL,NULL,'$2y$12$dJwNCdrvZ3jwyJvI0O593OcYg6d83jQhFTJzXud1iHBFmw6I8.SRW',1,NULL,'2026-04-10 01:13:49','2026-04-10 01:13:49',NULL,4,1),(5,'MARSYA INTAN NURAENI','MCU00031_32',NULL,NULL,NULL,'$2y$12$uNm0E.7eame56oYKKIIzMeIWgA6zxiaJdDMM89iEXsh4hrYYKKoIK',1,NULL,'2026-04-10 01:18:51','2026-04-10 01:18:51',NULL,4,1),(6,'NENENG JULIANTI','MCU00032_33',NULL,NULL,NULL,'$2y$12$vi8bWBEeVGi4azwAioKTGeKTeJtl2VJwRKjN0wtZokugbzi3MFvdi',1,NULL,'2026-04-10 01:47:29','2026-04-10 01:47:29',NULL,4,1),(7,'KEUKEU FAMESA','MCU00033_34',NULL,NULL,NULL,'$2y$12$rkN4Q5lLXPgh6VzYf4JNsuJ5Hh.TVyqFB.3y6ao4o.EuSZ04D4NOq',1,NULL,'2026-04-10 01:49:49','2026-04-10 01:49:49',NULL,4,1),(8,'RENI SEPTIANI','MCU00034_35',NULL,NULL,NULL,'$2y$12$fjvmLpYXk7Ux/TUJhSbmwORJfDd.1gQ21MV5xQ8KG6KjlZBxwwqUK',1,NULL,'2026-04-10 01:56:48','2026-04-10 01:56:48',NULL,4,1),(9,'HELMI HERLINA','MCU00035_36',NULL,NULL,NULL,'$2y$12$RKygeIlYsBZ7Q61ogd9bVej31F4NdcqQ4RKE6v3TeDpFYWQadt.Aq',1,NULL,'2026-04-10 07:05:41','2026-04-10 07:05:41',NULL,4,1),(10,'dr dini','dr_dini','dr_dini@gmail.com',NULL,NULL,'$2y$12$f5zTIT088Lf64K7MzV6/0edibpLt6MuZFVDFQc0x9emGPGrvsATPm',1,NULL,'2026-04-14 22:50:53','2026-04-14 22:50:53',NULL,2,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validate_doctors`
--

DROP TABLE IF EXISTS `validate_doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validate_doctors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_mcu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_mcu` datetime DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result_mcu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doctor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `validate_doctors_client_id_index` (`client_id`),
  KEY `validate_doctors_no_mcu_index` (`no_mcu`),
  KEY `validate_doctors_name_index` (`name`),
  KEY `validate_doctors_gender_index` (`gender`),
  KEY `validate_doctors_result_mcu_index` (`result_mcu`),
  KEY `validate_doctors_doctor_index` (`doctor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validate_doctors`
--

LOCK TABLES `validate_doctors` WRITE;
/*!40000 ALTER TABLE `validate_doctors` DISABLE KEYS */;
/*!40000 ALTER TABLE `validate_doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'medical_check_up'
--

--
-- Dumping routines for database 'medical_check_up'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-08 23:59:01
